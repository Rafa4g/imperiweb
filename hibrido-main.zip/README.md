# 𓊈𒆜 INSTALADOR 𒆜𓊉
```

sudo apt update && sudo apt upgrade && sudo apt autoremove && sudo apt autoclean && apt install wget -y; bash <(wget -qO- raw.githubusercontent.com/ruck18/hibrido/main/ssh-plus)
```

#  𓊈𒆜 PAINEL SSH 𒆜𓊉
```

✅ PAINEL WEB

✅ BOT TELEGRAM

✅ V2RAY  FUNCIONANDO

✅ CHECKUSER CONECTA4G

✅ CHECKUSER GL TUNNEL  MOD

✅ BADVPN PRO

✅ MENU APACHE

✅ PORTAS ORACLE AUTOMÁTICO

✅ MOSTRADOR DE CONSUMO

✅ TCPTWEAKER
